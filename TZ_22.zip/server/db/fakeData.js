'use strict';

module.exports = [
  {
    name: 'user1',
    email: 'user1@example.com',
    phone: '123-456-7890',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: 'user2',
    email: 'user2@example.com',
    phone: '987-654-3210',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: 'user3',
    email: 'user3@example.com',
    phone: '555-555-5555',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: 'user4',
    email: 'user4@example.com',
    phone: '111-222-3333',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: 'user5',
    email: 'user5@example.com',
    phone: '999-888-7777',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: 'user6',
    email: 'user6@example.com',
    phone: '444-555-6666',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: 'user7',
    email: 'user7@example.com',
    phone: '777-888-9999',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: 'user8',
    email: 'user8@example.com',
    phone: '666-777-8888',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: 'user9',
    email: 'user9@example.com',
    phone: '333-222-1111',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: 'user10',
    email: 'user10@example.com',
    phone: '123-789-4560',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];
